import { Component } from '@angular/core';
import { TranslateService } from 'ng2-translate';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent {

  constructor(private translate: TranslateService) {
    translate.addLangs(["en", "fr", "cn", "hi"]);
    translate.setDefaultLang('en');

    let browserLang = translate.getBrowserLang();
    translate.use(browserLang.match(/en|fr|cn|hi/) ? browserLang : 'en');
  }

  changeLanguage(lang) {
    this.translate.use(lang);
  }
}
